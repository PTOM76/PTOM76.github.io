package ml.pkom.test;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

public class Plugin extends JavaPlugin {

    public final String MOD_ID = "test"; // MODID
    public final String MOD_NAME = "TestPlugin"; // MOD名
    public final String MOD_VER = "1.0.0"; // MODバージョン
    public final String MOD_AUT = "K"; // MOD開発者

    // プラグインの有効時に呼び出されるメソッド
    @Override
    public void onEnable()
    {
        // コンソールへ出力
        getLogger().info("TestPlugin is enabled!");
    }

    // プラグインの無効時に呼び出されるメソッド
    @Override
    public void onDisable()
    {
        // コンソールへ出力
        getLogger().info("TestPlugin is disabled!");
    }

    // コマンドが実行された時に呼び出されるメソッド
    public boolean onCommand(CommandSender sender, Command cmd, String str, String[] args)
    {
        // helloworld
        if(cmd.getName().equalsIgnoreCase("helloworld")){
            // コンソールへ出力
            getLogger().info("Hello, World!");
            return true;
        }
        return false;
    }

}