screen -S spigot-1.12.2
cd ./run
java -server -Xms1G -Xmx1G -jar "spigot-1.12.2.jar" nogui