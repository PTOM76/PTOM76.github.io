#!/bin/sh
./maven/bin/mvn -f ./pom.xml clean install